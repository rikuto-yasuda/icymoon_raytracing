////////////////////////////////////////////////////////////////////////
// libraytrace testing testing.cpp
//  This program has been written in C++.
//  Copyright (C) 2005 Miyamoto Luisch.
#include "testing.h"
