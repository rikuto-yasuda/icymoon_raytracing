#ifndef RTC_TESTING_PLASMA_TRACE
#define RTC_TESTING_PLASMA_TRACE

#include <iostream>
#include "../../raytrace.h"
#include "../../model.h"
#include "../../planet.h"

#endif
