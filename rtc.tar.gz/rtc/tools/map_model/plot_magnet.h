#ifndef RAYTRACE_MISC_MAGNET_H
#define RAYTRACE_MISC_MAGNET_H

void plot_magnet(
   const char* pref,
   const rtc::basic_magnet_model& m,
   const double mlt,
   const double mlat
);

#endif
